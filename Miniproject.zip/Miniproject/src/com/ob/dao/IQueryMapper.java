package com.ob.dao;

public interface IQueryMapper {

	String CUSTOMER_INSERT_QRY ="insert into customer values(?,?,?,?,?,SYSDATE,jdbc1_seq1.NEXTVAL)" ;
	String USER_INSERT_QRY ="insert into accountmaster values" ;
	

}
